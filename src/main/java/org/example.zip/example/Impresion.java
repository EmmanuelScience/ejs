package org.example;

public interface Impresion {
    void imprimirTodo();
}
