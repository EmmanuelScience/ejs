package pajaro;

public interface Bucear {
    public void bucear();
}
