package pajaro;

public class Avestruces extends Pajaro  {

}
