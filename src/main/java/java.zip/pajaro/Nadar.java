package pajaro;

public interface Nadar {
    public void nadar();
}
