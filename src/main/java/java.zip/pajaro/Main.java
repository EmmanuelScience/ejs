package pajaro;

public class Main {

        public static void main(String[] args) {
            Pato p = new Pato();
            p.volar();
            p.nadar();

            Pato p2 = new Pato();
            p2.volar();

            Murcielago m = new Murcielago();
            m.volar();
        }
}
