package pajaro;

public class Murcielago extends Pajaro implements Volar {

    @Override
    public void volar() {
        System.out.println("Soy un murciélago y estoy volando");
    }

}
