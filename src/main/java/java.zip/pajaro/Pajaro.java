package pajaro;

public abstract class Pajaro  {

}
