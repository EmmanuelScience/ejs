package pajaro;

public interface Volar {
    public void volar();
}
